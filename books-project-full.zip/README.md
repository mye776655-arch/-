Books Project (Laravel)

Features:
- Add Book
- Edit Book
- Soft Delete using status
- Simple CRUD

Run:
php artisan migrate
php artisan serve

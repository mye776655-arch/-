<h1>Books</h1>
<a href="/books/create">Add Book</a>
@foreach($books as $book)
<p>{{ $book->title }} - {{ $book->author }}</p>
<a href="/books/{{$book->id}}/edit">Edit</a>
<form method="POST" action="/books/{{$book->id}}">
@csrf
@method('DELETE')
<button>Delete</button>
</form>
@endforeach

<h1>Edit Book</h1>
<form method="POST" action="/books/{{$book->id}}">
@csrf
@method('PUT')
<input name="title" value="{{$book->title}}">
<input name="author" value="{{$book->author}}">
<input name="year_published" value="{{$book->year_published}}">
<button>Update</button>
</form>

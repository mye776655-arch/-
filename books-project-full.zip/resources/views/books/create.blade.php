<h1>Add Book</h1>
<form method="POST" action="/books">
@csrf
<input name="title" placeholder="title">
<input name="author" placeholder="author">
<input name="year_published" placeholder="year">
<button>Add</button>
</form>
